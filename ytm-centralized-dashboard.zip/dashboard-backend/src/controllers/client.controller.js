const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();
const axios = require("axios");
const clientModel = require("../models/client.model");
const health = require("../models/health.model");
const { classifyAxiosError } = require("../utils/httpError");
const eventBus = require('../utils/eventBus'); 


// add each row non-exclusive flags
const withFlags = (rows) =>
  rows.map((r) => ({ ...r, status_flags: health.computeHealthFlags(r) }));

exports.getAllClients = async (req, res) => {
  try {
    const clients = await prisma.clientApplication.findMany({
      include: { services: true },
    });
    res.json(withFlags(clients));
  } catch (err) {
    console.error("Error in getAllClients:", err.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

exports.registerApp = async (req, res) => {
  const payload = req.body || {};
  const appId = payload.appId || payload.app_id;

  try {
    const {
      appId,
      title,
      version,
      url,
      apiUrl,
      proctorEdu,
      proctorio,
      superset,
      services,
    } = req.body;

    if (!appId) {
      return res.status(400).json({ error: "Invalid request payload" });
    }

    // 1) Update/insert client application
    let clientApp = await clientModel.findClientByAppId(appId);
    if (!clientApp) {
      clientApp = await clientModel.createClient(
        appId,
        title,
        version,
        url,
        apiUrl,
        proctorEdu,
        proctorio,
        superset
      );
    } else {
      clientApp = await clientModel.updateClient(
        appId,
        title,
        version,
        url,
        apiUrl,
        proctorEdu,
        proctorio,
        superset
      );
    }

    if (Array.isArray(services)) {
      for (const svc of services) {
        await prisma.services.upsert({
          where: { id: svc.id },
          create: {
            id: svc.id,
            appId: svc.app_id,
            type: svc.type,
            client_applications: { connect: { app_id: clientApp.app_id } },
          },
          update: {
            // in case type changed
            type: svc.type,
          },
        });
      }
    }
    // Mark registration as a successful ping and active app
    await clientModel.updatePingStatus(appId, true);
    try {
      await health.markAppInfoJob(appId, true);
      await health.markReachability(appId, true);
    } catch {}
    clientApp = await clientModel.findClientByAppId(appId);

    // 4) Emit event and respond
        // 4) Emit event and respond
    const flaggedClient = {
      ...clientApp,
      status_flags: health.computeHealthFlags(clientApp),
    };
    eventBus.emit("app_registered", {
      clientId: clientApp.client_id,
      appId,
    });
    eventBus.emit('client_update', flaggedClient);

    res.status(200).json({ message: "App registered successfully", clientApp });
  } catch (err) {
    console.error("Register App Error:", err);
    // mark job failure if we know the app id
    if (req?.body?.appId) {
      try {
        await health.markAppInfoJob(req.body.appId, false);
      } catch {}
    }
    res.status(500).json({ error: "Internal Server Error" });
  }
};

exports.syncAppInfo = async (req, res) => {
  const { appId } = req.params;

  try {
    const client = await prisma.clientApplication.findUnique({
      where: { app_id: appId },
      include: { services: true },
    });

    if (!client) {
      return res.status(404).json({ error: "Client application not found" });
    }

    const baseUrl = ("http://localhost:8085/ytm.webview/" || "").replace(
      /\/$/,
      ""
    );
    // const baseUrl = (client.url || "").replace(/\/$/, "");
    if (!baseUrl) {
      return res
        .status(400)
        .json({ error: "Client has no API URL configured" });
    }

    const servletUrl = `${baseUrl}/app/info`;
    try {
      const { data: appInfo } = await axios.get(servletUrl, {
        headers: "application/json",
      });

      if (!appInfo || typeof appInfo !== "object" || !appInfo.title) {
        return res.status(502).json({
          status: "error",
          error: {
            type: "InvalidResponse",
            message: "Invalid response payload from target application",
            code: "INVALID_RESPONSE",
            request: {
              method: "GET",
              url: servletUrl,
              appId: client.app_id,
              timestamp: new Date().toISOString(),
            },
            response: { status: 200, body: JSON.stringify(appInfo) },
          },
        });
      }

      await clientModel.updateClient(
        client.app_id,
        appInfo.title,
        appInfo.version,
        appInfo.url,
        appInfo.apiUrl,
        appInfo.proctorEdu,
        appInfo.proctorio,
        appInfo.superset
      );

      if (Array.isArray(appInfo.services)) {
        for (const svc of appInfo.services) {
          await prisma.services.upsert({
            where: { id: svc.id },
            create: {
              id: svc.id,
              app_id: svc.app_id,
              type: svc.type,
              client_applications: { connect: { app_id: client.app_id } },
            },
            update: {
              // in case type changed
              type: svc.type,
            },
          });
        }
      }

      await clientModel.updatePingStatus(client.app_id, true);
      await Promise.all([
        health.markManualSyncSuccess(client.app_id),
        health.markReachability(client.app_id, true),
      ]);

      const finalClient = await clientModel.findClientByAppId(client.app_id);
      const finalWithFlags = {
        ...finalClient,
        status_flags: health.computeHealthFlags(finalClient),
      };
      eventBus.emit('client_update', finalWithFlags);
      return res.json(finalWithFlags);
    } catch (e) {
      console.error(`Failed to sync app info for ${client.app_id}:`, e.message);
      await clientModel.updatePingStatus(client.app_id, false, false);

      try {
        await health.markReachability(client.app_id, false);
      } catch {}

      const failedClient = await clientModel.findClientByAppId(client.app_id);
      const classified = classifyAxiosError(e, {
        method: "GET",
        url: servletUrl,
        appId: client.app_id,
      });

      // include current flags so the row can update immediately in UI
      classified.client = {
        ...failedClient,
        status_flags: health.computeHealthFlags(failedClient),
      };

      const statusCode = /^\d+$/.test(classified?.error?.code || "")
        ? Number(classified.error.code)
        : 503;
      return res.status(statusCode).json(classified);
    }
  } catch (e) {
    console.error("Application information sync failed", e);
    return res.status(500).json({
      status: "error",
      error: {
        type: "ApplicationError",
        message: "Sync failed",
        code: "INTERNAL_ERROR",
        details: e.message,
      },
    });
  }
};
